function varargout = matchgui(varargin)
% viewmatch3dgui for displaying matched features in two 3D volume data.
% Miao Zhang, University of Missouri
% Based on the matchgui programmed by Deshan Yang, Washington University
% Email: dyang@radonc.wustl.edu

persistent input_var_name;
if isempty(varargin)

elseif ~ischar(varargin{1}) && ~isa(varargin{1},'timer')
	for n = 1:nargin
		if ~ischar(varargin{n})
			input_var_name = [input_var_name '-' inputname(n)];
		end
	end
end

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @matchgui_OpeningFcn, ...
                   'gui_OutputFcn',  @matchgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

if ~isempty(gcbf) && ~isempty(input_var_name)
    set(gcbf,'Name',['ViewMatch3D - ' input_var_name]);
    input_var_name = [];
end



% --- Executes just before matchgui is made visible.
function matchgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to matchgui (see VARARGIN)

% Choose default command line output for matchgui
handles.output = hObject;
handles.aspects = [1 1 1];
handles.landmarks = [];
handles.matched_points_indices_1 = [];
handles.matched_points_indices_2 = [];
handles.landmarks1 = [];
handles.landmarks2 = [];
handles.descriptors1=[];
handles.descriptors2=[];
handles.slicenos = [1 1 1];
handles.flipX = 0;
handles.flipY = 1;
handles.flipZ = 0;
handles.rotation=0;
handles.figure_name = '';
handles.hide_all_features = 0;

handles.nlandmark = 1;

handles.max = 2000;
handles.min=0;
handles.sorting_method = 1;
handles.display_numbers = 0;
handles.to_compute_center = 1;

%handles.axes_handles = [handles.axes1a,handles.axes1b,handles.axes2a,handles.axes2b,handles.axes3a,handles.axes3b];
handles.slice_offsets = zeros(1,6);
handles.windowcenter = [];
handles.windowwidth = [];
handles.PositionRefineMenus = [handles.Refine_Method_1 handles.Refine_Method_2 handles.Refine_Method_3 handles.Refine_Method_4 ...
    handles.Refine_Method_5 handles.Refine_Method_6 handles.Refine_Method_7 handles.Refine_Method_8];
handles.PositionRefineMethod = 1;
handles.PositionRefineBidirectional = 0;

handles.mask1 = [];
handles.mask1_is_generated_from_contours = false;
handles.mask2 = [];
handles.mask2_is_generated_from_contours = false;
handles.mask_mode = '';
handles.feature_scale=1;
handles.manual_verify_mode = false;

if isempty(varargin)
    fprintf('Please Input Data. Refer to our GitHub for instructions https://github.com/deshanyang/Lung-DIR-QA/blob/main')
    fprintf('\n')
else
handles.image1 =  varargin{1};
handles.image2 =  varargin{2};
if isa(handles.image1,'uint16')
    handles.image1=single(handles.image1);
end
if isa(handles.image2,'uint16')
    handles.image2=single(handles.image2);
end

if ~isequal(size(handles.image1),size(handles.image2))
    dif1=size(handles.image1,1)-size(handles.image2,1);
    dif2=size(handles.image1,2)-size(handles.image2,2);
    dif3=size(handles.image1,3)-size(handles.image2,3);

    if dif1~=0 && dif1>0
        added=ones(abs(dif1),size(handles.image2,2),size(handles.image2,3))*max(handles.image2(:));
        handles.image2=cat(1,handles.image2,added);
    elseif dif1~=0 && dif1<0
        added=ones(abs(dif1),size(handles.image1,2),size(handles.image1,3))*max(handles.image1(:));
        handles.image1=cat(1,handles.image1,added);
    else
    end

    if dif2~=0 && dif2>0
        added=ones(size(handles.image1,1),abs(dif2),size(handles.image2,3))*max(handles.image2(:));
        handles.image2=cat(2,handles.image2,added);
    elseif dif2~=0 && dif2<0
        added=ones(size(handles.image1,1),abs(dif2),size(handles.image1,3))*max(handles.image1(:));
        handles.image1=cat(2,handles.image1,added);
    else
    end

    if dif3~=0 && dif3>0
        added=ones(size(handles.image2,1),size(handles.image2,2),abs(dif3))*max(handles.image2(:));
        handles.image2=cat(3,handles.image2,added);
    elseif dif3~=0 && dif3<0
        added=ones(size(handles.image1,1),size(handles.image1,2),abs(dif3))*max(handles.image1(:));
        handles.image1=cat(3,handles.image1,added);
    else
    end

    %error('two volume data should be of the same size');
end
max_dim = max(size(handles.image1));
max_zoom = ceil(log2(max_dim)*2);
set(handles.zoom_slider,'value',max_zoom);
set(handles.zoom_slider,'max',max_zoom);

handles.min = min(handles.image1(:));
handles.max = max(handles.image1(:));

dim = mysize(handles.image1);
handles.dim = dim;
% 	handles.slicenos = round(dim/2);

upsampling = false;
zoom_factor = 1;
sorting_method = 1;

if( length(varargin) > 2 )
    skip=0;
    for n = 3:length(varargin)
        if skip==1
            skip=0;
            continue;
        end
        if ischar(varargin{n})
            switch lower(varargin{n})
                case {'ratio','ratios'}
                    handles.aspects = varargin{n+1};
                    skip=1;
                    if length(handles.aspects) == 1
                        handles.aspects = [1 1 handles.aspects];
                    end
                case 'flipz'
                    handles.flipZ=varargin{n+1};
                    skip=1;
                case 'landmarks'
                    handles.landmarks=varargin{n+1};
                    skip=1;
                case 'landmarks1'
                    % Landmarks only for image 1
                    handles.landmarks1=varargin{n+1};
                    skip=1;
                case 'landmarks2'
                    % Landmarks only for image 2
                    handles.landmarks2=varargin{n+1};
                    skip=1;
                case 'descriptors1'
                    % Landmarks only for image 1
                    handles.descriptors1=varargin{n+1};
                    skip=1;
                case 'descriptors2'
                    handles.descriptors2=varargin{n+1};
                    skip=1;
                case 'matched_points_indices_1'
                    handles.matched_points_indices_1=varargin{n+1};
                    skip=1;
                case 'matched_points_indices_2'
                    handles.matched_points_indices_2=varargin{n+1};
                    skip=1;
                case {'windowcenter','window_center'}
                    handles.windowcenter = varargin{n+1};
                    skip=1;
                case {'windowwidth','window_width'}
                    handles.windowwidth = varargin{n+1};
                    skip=1;
                case {'window','window_level','window_setting'}
                    handles.windowwidth = diff(varargin{n+1});
                    handles.windowcenter = mean(varargin{n+1});
                    skip=1;
                case {'mask1','contour1','mask_1','contour_1'}
                    handles.mask1 = uint32(varargin{n+1});
                    handles.mask1_is_generated_from_contours = false;
                    skip=1;
                case {'mask2','contour2','mask_2','contour_2'}
                    handles.mask2 = uint32(varargin{n+1});
                    handles.mask2_is_generated_from_contours = false;
                    skip=1;
                case {'mask_mode'}
                    handles.mask_mode = varargin{n+1};
                    skip=1;
                case {'to_compute_center'}
                    handles.to_compute_center = varargin{n+1};
                    skip=1;
                case 'name'
                    handles.figure_name = varargin{n+1};
                    skip=1;
                case {'manually_placed_positions','gt','refined'}
                    handles.manually_placed_positions = varargin{n+1};
                    if ndims(handles.manually_placed_positions) == 2
                        handles.manually_placed_positions = cat(3,handles.manually_placed_positions(:,2:4),handles.manually_placed_positions(:,6:8));
                    end
                    skip=1;
                case 'upsampling'
                    upsampling = true;
				case 'manual_verify_mode'
					handles.manual_verify_mode=varargin{n+1};
                    skip=1;
                case 'zoom'
                    zoom_factor = varargin{n+1};
                    skip=1;
                case 'sorting_method'
                    sorting_method = varargin{n+1};
                    skip=1;
                otherwise
                    if isfield(handles,varargin{n})
                        handles.(varargin{n}) = varargin{n+1};
                    end
            end
        elseif ischar(varargin{n-1})
            continue;
        else
            if numel(varargin{n}) == 3
                handles.aspects = varargin{n};
            elseif numel(varargin{n}) == 1
                handles.aspects = [1 1 varargin{n}];
            end
        end
    end
end
if size(handles.landmarks,1)==0
    error('no land marks loaded');
end
if isa(handles.landmarks,'uint16')
    handles.landmarks=single(handles.landmarks);
end
handles.landmarks0 = handles.landmarks;
N = size(handles.landmarks,1);
handles.good_landmark_flags = ones(1,N);
handles.landmark_scores = zeros(1,N);
if ~isfield(handles,'manually_placed_positions') || size(handles.manually_placed_positions,1)~=N
    handles.manually_placed_positions = nan(N,3,2);
end
if handles.to_compute_center == 1
    handles.landmarks_center1 = mean(handles.landmarks(:,2:4),1);
    handles.landmarks_center2 = mean(handles.landmarks(:,6:8),1);
else
    handles.landmarks_center1 = [0 0 0];
    handles.landmarks_center2 = [0 0 0];
end
handles.landmarks0_centered = handles.landmarks;
handles.landmarks0_centered(:,2:4) = handles.landmarks0_centered(:,2:4)-repmat(handles.landmarks_center1,[N,1]);
handles.landmarks0_centered(:,6:8) = handles.landmarks0_centered(:,6:8)-repmat(handles.landmarks_center2,[N,1]);

handles.aspects_2 = handles.aspects.^2;
handles.indices = 1:length(handles.landmarks);
[~,orderI]=sort(handles.landmarks0(:,10));
set(handles.popupmenu3,'value',1);

handles.indices = orderI;
handles.landmarks(:,:)=handles.landmarks0(orderI,:);

if isempty(handles.mask1) && isempty(handles.mask2)
    set(handles.checkbox_show_edges,'enable','off');
else
    set(handles.checkbox_show_edges,'value',1);
end
if isempty(handles.landmarks1) && isempty(handles.landmarks2)
    set(handles.checkbox_display_additional_points,'enable','off');
end

if upsampling
    set(handles.checkbox_upsample,'value',1);
end

if zoom_factor < 1 && zoom_factor > 0
    set(handles.zoom_slider,'value',max_zoom*zoom_factor);
end

if sorting_method > 1
    methods = get(handles.popupmenu3,'string');
    if sorting_method <= length(methods)
        set(handles.popupmenu3,'value',sorting_method);
%         popupmenu3_Callback(handles.popupmenu3, [], handles);
    else
        sorting_method=1;
    end
end

set(handles.Coordinate1,'BackgroundColor',[1 0.5 0]);
set(handles.Coordinate2,'BackgroundColor',[1 0.5 0]);
set(handles.Manual_Coordinate_Text_1,'BackgroundColor',[0 1 1]*0.75);
set(handles.Manual_Coordinate_Text_2,'BackgroundColor',[0 1 1]*0.75);
if handles.manual_verify_mode
	set(handles.checkbox_good_match,'string','Landmarks in blue is better','visible','off');
    set(handles.text_score,'visible','on','enable','on');
    set(handles.popupmenu_score,'visible','on','enable','on');
    set(handles.checkbox_show_vector,'visible','off','enable','off');
    
    if handles.manual_verify_mode == 2
        % To score the manual matching accuracy
        set(handles.popupmenu_score,'string',{'Very good (Error < 1 voxel)','Good (Error < 2 voxels)','OK (Error < 3 voxels)','Not Good (Error < 4 voxels)','Very Bad (Error > voxels)'});
    end
end


handles = init_window_controls(handles);

guidata(hObject, handles);
guidata(handles.figure1,handles);
UpdateDisplay(handles);

% Update handles structure
guidata(hObject, handles);

if sorting_method > 1
%     handles.sorting_method = sorting_method;
    popupmenu3_Callback(handles.popupmenu3, [], handles);
end
end
% --- Outputs from this function are returned to the command line.
function varargout = matchgui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
%varargout{1} = handles.output;
varargout{1} = handles.output;
varargout{2} = handles.figure1;
if ~isempty(handles.figure_name)
    set(handles.figure1,'Name',handles.figure_name);
end


%=====================================================
% Display function
%=====================================================
function UpdateDisplay(handles,panels)
haxes = [handles.axes1a handles.axes1b handles.axes2a handles.axes2b handles.axes3a handles.axes3b];
displaymodes = [1 1 2 2 3 3];
leftrights = [1 2 1 2 1 2];

if ~exist('panels','var')
    panels = 1:6;
end
for k = panels
    handles.axes=haxes(k);
    handles.displaymode=displaymodes(k);
    handles.leftright=leftrights(k);
    UpdateDisplaySub(handles,k);
end

landmark = handles.landmarks(handles.nlandmark,:);
point1 = landmark(2:5);
point2 = landmark(6:9);
mpos1 = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
mpos2 = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
has_manual_position = (all(~isnan(mpos1)) + all(~isnan(mpos2)))>0;
if ~has_manual_position
    set(handles.Manual_Coordinate_Text_1,'visible','off');
    set(handles.Manual_Coordinate_Text_2,'visible','off');
else
    mpos1=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
    dist1 = mpos1-point1(1:3);
    dist1 = dist1.*handles.aspects;
    if any(isnan(dist1))
        set(handles.Manual_Coordinate_Text_1,'visible','off');
    else
        dist1mag = sqrt(sum(dist1.*dist1));
		if handles.manual_verify_mode
			dist_str1 = sprintf('(%.1f, %.1f, %.1f)',round(mpos1(2)),round(mpos1(1)),round(mpos1(3)));
			set(handles.Manual_Coordinate_Text_1,'string',sprintf('Landmark 1: %s',dist_str1),'visible','on');
		else
			dist_str1 = sprintf('(%.1f, %.1f, %.1f), dist=(%.1f, %.1f, %.1f), error =%.2f',mpos1(2),mpos1(1),mpos1(3),dist1(2),dist1(1),dist1(3),dist1mag);
			set(handles.Manual_Coordinate_Text_1,'string',sprintf('Manual Position 1: %s',dist_str1),'visible','on');
		end
    end
    mpos2=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
    dist2 = mpos2 - point2(1:3);
    dist2 = dist2.*handles.aspects;
    if any(isnan(dist2))
        set(handles.Manual_Coordinate_Text_2,'visible','off');
    else
        dist2mag = sqrt(sum(dist2.*dist2));
		if handles.manual_verify_mode
			dist_str2 = sprintf('(%.1f, %.1f, %.1f)',round(mpos2(2)),round(mpos2(1)),round(mpos2(3)));
			set(handles.Manual_Coordinate_Text_2,'string',sprintf('Landmark 2: %s',dist_str2),'visible','on');
		else
			dist_str2 = sprintf('(%.1f, %.1f, %.1f), dist=(%.1f, %.1f, %.1f), error =%.2f',mpos2(2),mpos2(1),mpos2(3),dist2(2),dist2(1),dist2(3),dist2mag);
			set(handles.Manual_Coordinate_Text_2,'string',sprintf('Manual Position 2: %s',dist_str2),'visible','on');
		end
    end
    
end

%
function [img2dout,xs,ys]=resize_img(img2d,handles)
imgdim=size(img2d);
xs = 1:imgdim(2);
ys = 1:imgdim(1);
if get(handles.checkbox_upsample,'value')==0
    img2dout=img2d;
    return;
end

scale=4;
if scale == 4
   % By 4
   img2dout = imresize(single(img2d),4);
   xs = (1:4*imgdim(2))*0.25+0.375;
   ys = (1:4*imgdim(1))*0.25+0.375;
else
    % by 2
    img2dout = imresize(single(img2d),2);
    xs = (1:2*imgdim(2))*0.5+0.25;
    ys = (1:2*imgdim(1))*0.5+0.25;
end
    
   
%
function UpdateDisplaySub(handles,axesnum)
dim = handles.dim;
set(handles.figure1,'CurrentAxes',handles.axes);
axes(handles.axes);
HA = handles.axes;
handles.nlandmark = max(str2num(get(handles.key_input,'String')),1);
windowcenter = str2num(get(handles.windowcenterinput,'String'));
windowwidth = str2num(get(handles.windowwidthinput,'String'));
minv = (windowcenter - windowwidth/2);
maxv = (windowcenter + windowwidth/2);

if maxv<= minv
	minv = handles.min;
	maxv = handles.max;
end

slice_offset = handles.slice_offsets(axesnum);

map = gray(64);
oldfcn = get(handles.axes,'buttonDownFcn');
H = [];
landmark = handles.landmarks(handles.nlandmark,:);
landmark_centered = handles.landmarks0_centered(handles.indices(handles.nlandmark),:);
N = size(handles.landmarks,1);
str1 = sprintf('# %d (%d,%d)',handles.nlandmark,handles.indices(handles.nlandmark),N);
set(handles.key,'string',str1);
set(handles.match_quality, 'String',num2str(landmark(10)));
point1 = landmark(2:5);
point1c = landmark_centered(2:5);
if handles.manual_verify_mode
	set(handles.Coordinate1, 'String',['(',num2str(round(point1(2)),'%.1f'),' ,',num2str(round(point1(1)),'%.1f'),' ,',num2str(round(point1(3)),'%.1f'),')'],'ForegroundColor',[0 0 0]);
else
	set(handles.Coordinate1, 'String',['(',num2str(point1(2),'%.1f'),' ,',num2str(point1(1),'%.1f'),' ,',num2str(point1(3),'%.1f'),')']);
end
% set(handles.Scale1, 'String',num2str(point1(4),'%.1f'));

point2 = landmark(6:9);
point2c = landmark_centered(6:9);
if handles.manual_verify_mode
	set(handles.Coordinate2, 'String',['(',num2str(round(point2(2)),'%.1f'),' ,',num2str(round(point2(1)),'%.1f'),' ,',num2str(round(point2(3)),'%.1f'),')']);
else
	set(handles.Coordinate2, 'String',['(',num2str(point2(2),'%.1f'),' ,',num2str(point2(1),'%.1f'),' ,',num2str(point2(3),'%.1f'),')']);
end
% set(handles.Scale2, 'String',num2str(point2(4),'%.1f'));
set(handles.Scale_Text, 'String',sprintf('Scale: %.2f -- %.2f',point1(4),point2(4)));

if handles.good_landmark_flags(handles.indices(handles.nlandmark))
    set(handles.checkbox_good_match,'value',1);
else
    set(handles.checkbox_good_match,'value',0);
end

% if handles.landmark_scores(handles.indices(handles.nlandmark))
    set(handles.popupmenu_score,'value',handles.landmark_scores(handles.indices(handles.nlandmark))+1);
% end

mpos = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,handles.leftright);
has_manual_position = all(~isnan(mpos));
% if ~has_manual_position
%     set(handles.Manual_Coordinate_Text_1,'visible','off');
% else
%     set(handles.Manual_Coordinate_Text_1,'visible','on');
%     mpos1=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
%     dist1 = mpos1-point1(1:3);
%     dist1 = dist1.*handles.aspects_2;
%     if any(isnan(dist1))
%         dist_str1 = '';
%     else
%         dist1 = sqrt(sum(dist1.*dist1));
%         dist_str1 = sprintf('(%.1f, %.1f, %.1f), dist=%.2f',mpos1(2),mpos1(1),mpos1(3),dist1);
%     end
%     mpos2=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
%     dist2 = mpos2 - point2(1:3);
%     dist2 = dist2.*handles.aspects_2;
%     if any(isnan(dist2))
%         dist_str2 = '';
%     else
%         dist2 = sqrt(sum(dist2.*dist2));
%         dist_str2 = sprintf(' -- (%.1f, %.1f, %.1f), dist=%.2f',mpos2(2),mpos2(1),mpos2(3),dist2);
%     end
%     set(handles.Manual_Coordinate_Text_1,'string',sprintf('Manual Position: %s%s',dist_str1,dist_str2));
% end

dist = sqrt((point1c(2)-point2c(2))^2*handles.aspects_2(2)+(point1c(1)-point2c(1))^2*handles.aspects_2(1)+(point1c(3)-point2c(3))^2*handles.aspects_2(3));
set(handles.text_distance, 'String',sprintf(['Distance = %.1f (',num2str(point1c(2)-point2c(2),'%.1f'),' ,',num2str(point1c(1)-point2c(1),'%.1f'),' ,',num2str(point1c(3)-point2c(3),'%.1f'),')'],dist));

% maxscale= round(max(point1(4),point2(4)));
maxscale=2;
% maxscale= round(max(point1(4),point2(4))*2)/2;
% maxscale= (max(point1(4),point2(4))*2)/2;
zoomfactor=2^(get(handles.zoom_slider,'value')/2);
start1=max(1,round(point1(1:3)-zoomfactor*maxscale./handles.aspects));
stop1=min(round(point1(1:3)+zoomfactor*maxscale./handles.aspects),dim);
start2=max(1,round(point2(1:3)-zoomfactor*maxscale./handles.aspects));
stop2=min(round(point2(1:3)+zoomfactor*maxscale./handles.aspects),dim);

% Other points on the same slices

other_matched_points = [];
other_matched_points_2 = [];
matched_points_diff = [];
unmatched_points = [];

draw_vector = get(handles.checkbox_show_vector,'value')==1;
draw_edges = get(handles.checkbox_show_edges,'value')==1;
draw_other_features = get(handles.checkbox_display_other_points,'value') == 1;
draw_unmatched_features = get(handles.checkbox_display_additional_points,'value') == 1;
mask2d = [];

switch handles.leftright      
    case 1
        point=point1;
        point_diff = point2-point1;
        start=start1;
        stop=stop1;
        img=handles.image1;
        if draw_other_features
%             other_matchedidxes = [1:handles.nlandmark-1 handles.nlandmark+1:N];
            switch handles.displaymode
                case 3
                    other_matched_points_indices = find(round(handles.landmarks(:,4))==round(point1(3))+slice_offset);
                case 1
                    other_matched_points_indices = find(round(handles.landmarks(:,2))==round(point1(1))+slice_offset);
                case 2
                    other_matched_points_indices = find(round(handles.landmarks(:,3))==round(point1(2))+slice_offset);
            end
            if ~isempty(other_matched_points_indices)
                other_matched_points_indices=other_matched_points_indices(other_matched_points_indices~=handles.nlandmark);
                other_matched_points=handles.landmarks(other_matched_points_indices,2:5);
                other_matched_points_2=handles.landmarks(other_matched_points_indices,6:9);
                matched_points_diff=other_matched_points_2-other_matched_points;
                other_matched_points_indices=handles.indices(other_matched_points_indices);
            end
%             other_matched_points = handles.landmarks(other_matched_points_indices,:);
%             if ~isempty(other_matched_points),other_matched_points=other_matched_points(:,2:5);end
        end
        
        if draw_unmatched_features && ~isempty(handles.landmarks1)
            switch handles.displaymode
                case 3
                    unmatched_point_indices = find(round(handles.landmarks1(:,3))==round(point1(3))+slice_offset);
                case 1
                    unmatched_point_indices = find(round(handles.landmarks1(:,1))==round(point1(1))+slice_offset);
                case 2
                    unmatched_point_indices = find(round(handles.landmarks1(:,2))==round(point1(2))+slice_offset);
            end
            unmatched_points = handles.landmarks1(unmatched_point_indices,:);
        end
        
        if draw_edges && ~isempty(handles.mask1)
            switch handles.displaymode
                case 3
                    z = min(max(round(point1(3))+slice_offset,1),dim(3));
                    sliceno = z;
                    mask2d = reshape(handles.mask1(start(1):stop(1), start(2):stop(2), z),...
                        stop(1)-start(1)+1,stop(2)-start(2)+1);
%                     z2 = min(max(round(point2(3))+slice_offset,1),dim(3));
%                     mask2d2 = reshape(handles.mask2(start2(1):stop2(1), start2(2):stop2(2), z2),...
%                         stop2(1)-start2(1)+1,stop2(2)-start2(2)+1);
%                     mask2d=single(mask2d)-single(mask2d2);
                case 1
                    y = min(max(round(point1(1))+slice_offset,1),dim(1));
                    sliceno = y;
                    mask2d = reshape(handles.mask1(y, start(2):stop(2), start(3):stop(3)),...
                        stop(2)-start(2)+1,stop(3)-start(3)+1);
%                     y2 = min(max(round(point2(1))+slice_offset,1),dim(1));
%                     mask2d2 = reshape(handles.mask2(y2, start2(2):stop2(2), start2(3):stop2(3)),...
%                         stop2(2)-start2(2)+1,stop2(3)-start2(3)+1);
%                     mask2d=single(mask2d)-single(mask2d2);
                case 2
                    x = min(max(round(point1(2))+slice_offset,1),dim(2));
                    sliceno = x;
                    mask2d = reshape(handles.mask1(start(1):stop(1), x, start(3):stop(3)),...
                        stop(1)-start(1)+1,stop(3)-start(3)+1);
%                     x2 = min(max(round(point2(2))+slice_offset,1),dim(2));
%                     mask2d2 = reshape(handles.mask2(start2(1):stop2(1), x2, start2(3):stop2(3)),...
%                         stop2(1)-start2(1)+1,stop2(3)-start2(3)+1);
%                     mask2d=single(mask2d)-single(mask2d2);
            end
        end
    case 2
        point=point2;
        point_diff = point1-point2;
        start=start2;
        stop=stop2;
        img=handles.image2;
        if draw_other_features
%             other_matchedidxes = [1:handles.nlandmark-1 handles.nlandmark+1:N];
            switch handles.displaymode
                case 3
                    other_matched_points_indices = find(round(handles.landmarks(:,8))==round(point2(3))+slice_offset);
                case 1
                    other_matched_points_indices = find(round(handles.landmarks(:,6))==round(point2(1))+slice_offset);
                case 2
                    other_matched_points_indices = find(round(handles.landmarks(:,7))==round(point2(2))+slice_offset);
            end
%             other_matched_points = handles.landmarks(other_matched_points_indices,:);
            if ~isempty(other_matched_points_indices)
                other_matched_points_indices=other_matched_points_indices(other_matched_points_indices~=handles.nlandmark);
                other_matched_points=handles.landmarks(other_matched_points_indices,6:9);
                other_matched_points_2=handles.landmarks(other_matched_points_indices,2:5);
                matched_points_diff=other_matched_points_2-other_matched_points;
                other_matched_points_indices=handles.indices(other_matched_points_indices);
            end
        end
        
        if draw_unmatched_features && ~isempty(handles.landmarks2)
            switch handles.displaymode
                case 3
                    unmatched_point_indices = find(round(handles.landmarks2(:,3))==round(point1(3))+slice_offset);
                case 1
                    unmatched_point_indices = find(round(handles.landmarks2(:,1))==round(point1(1))+slice_offset);
                case 2
                    unmatched_point_indices = find(round(handles.landmarks2(:,2))==round(point1(2))+slice_offset);
            end
            unmatched_points = handles.landmarks2(unmatched_point_indices,:);
        end
        
        if draw_edges && ~isempty(handles.mask2)
            switch handles.displaymode
                case 3
                    z = min(max(round(point2(3))+slice_offset,1),dim(3));
                    sliceno = z;
                    mask2d = reshape(handles.mask2(start(1):stop(1), start(2):stop(2), z),...
                        stop(1)-start(1)+1,stop(2)-start(2)+1);
                case 1
                    y = min(max(round(point2(1))+slice_offset,1),dim(1));
                    sliceno = y;
                    mask2d = reshape(handles.mask2(y, start(2):stop(2), start(3):stop(3)),...
                        stop(2)-start(2)+1,stop(3)-start(3)+1);
                case 2
                    x = min(max(round(point2(2))+slice_offset,1),dim(2));
                    sliceno = x;
                    mask2d = reshape(handles.mask2(start(1):stop(1), x, start(3):stop(3)),...
                        stop(1)-start(1)+1,stop(3)-start(3)+1);
            end
        end
        
end


if handles.good_landmark_flags(handles.indices(handles.nlandmark)) == 1
    point_type = 1; % is used to control the color of the circle
else
    point_type = 4;
end

switch handles.displaymode
	case 1	% Coronal
        % Display the image
        y = min(max(round(point(1)+slice_offset),1),dim(1));
        sliceno = point(1);
        img1 = reshape(img(y, start(2):stop(2), start(3):stop(3)),...
            stop(2)-start(2)+1,stop(3)-start(3)+1);
        if point(1)+slice_offset~= y && point(1)+slice_offset>= 1 && point(1)+slice_offset <= dim(1)
            y2 = y+sign(point(1)+slice_offset-y);
            img2 = reshape(img(y2, start(2):stop(2), start(3):stop(3)),...
                stop(2)-start(2)+1,stop(3)-start(3)+1);
            img = img1*abs(y2-point(1)-slice_offset)+img2*abs(y-point(1)-slice_offset);
        else
            img = img1;
        end
        img = img';
        [img,xs,ys]=resize_img(img,handles);
        H = image(xs,ys,img,'Parent',HA,'CDataMapping','scaled');
        axis off;
        zoom off;
        daspect(HA,[1/handles.aspects(1) 1/handles.aspects(3) 1]);
        if handles.flipX == 1
            set(gca,'XDir','reverse');
        else
            set(gca,'XDir','normal');
        end
        if handles.flipZ == 1
            set(gca,'YDir','reverse');
        else
            set(gca,'YDir','normal');
        end
        
        % Draw edges
        if draw_edges && ~isempty(mask2d)
            PlotContourFunction1(HA,mask2d',handles);
        end
        
        % Draw unmatched feature points
        if ~isempty(unmatched_points)
            for k = 1:size(unmatched_points,1)
                if unmatched_points(k,2)<start(2) || unmatched_points(k,2)>stop(2) || unmatched_points(k,3)<start(3) || unmatched_points(k,3)>stop(3); continue; end
                drawcircle(handles,unmatched_points(k,2)-start(2)+1,unmatched_points(k,3)-start(3)+1,unmatched_points(k,4),3,unmatched_point_indices(k));
            end
        end
        
        % Draw other feature points
        if ~isempty(other_matched_points)
            if draw_vector
                dxs = matched_points_diff(:,2);
                dys = matched_points_diff(:,3);
                xs0 = other_matched_points(:,2)-start(2)+1;
                ys0 = other_matched_points(:,3)-start(3)+1;
                hold on;quiver(HA,xs0,ys0,dxs,dys,0,'color',[0 1 0],'hittest','off');hold off;
            end
            for k = 1:size(other_matched_points,1)
                if other_matched_points(k,2)<start(2) || other_matched_points(k,2)>stop(2) || other_matched_points(k,3)<start(3) || other_matched_points(k,3)>stop(3); continue; end
                drawcircle(handles,other_matched_points(k,2)-start(2)+1,other_matched_points(k,3)-start(3)+1,other_matched_points(k,4),2,other_matched_points_indices(k));
            end
        end
        
        % Draw the focused feature point
		if handles.manual_verify_mode
			if all(handles.slice_offsets==0)
				% original 
				drawcircle(handles,point(2)-start(2)+1,point(3)-start(3)+1,point(4),point_type,handles.indices(handles.nlandmark));
			else
				% manual
				drawcircle(handles,mpos(2)-start(2)+1,mpos(3)-start(3)+1,point(4),8,handles.indices(handles.nlandmark));
			end
		else
			if slice_offset==0
				if draw_vector;hold on;quiver(HA,point(2)-start(2)+1,point(3)-start(3)+1,point_diff(2),point_diff(3),0,'color',[1 0 0 ],'hittest','off');hold off;end
				drawcircle(handles,point(2)-start(2)+1,point(3)-start(3)+1,point(4),point_type,handles.indices(handles.nlandmark));
			end
			
			% Draw the manually placed position of the focused feature points
			if has_manual_position
				if abs(mpos(1)-point(1)-slice_offset)<0.1
					drawcircle(handles,mpos(2)-start(2)+1,mpos(3)-start(3)+1,point(4),8,handles.indices(handles.nlandmark));
				end
			end
		end
        
	case 2	% Sagittal
        % Display the image
        x = min(max(round(point(2)+slice_offset),1),dim(2));
        sliceno = point(2);
        img1 = reshape(img(start(1):stop(1), x, start(3):stop(3)),...
            stop(1)-start(1)+1,stop(3)-start(3)+1);
        if point(2)+slice_offset~= x && point(2)+slice_offset>= 1 && point(2)+slice_offset <= dim(2)
            x2 = x+sign(point(2)+slice_offset-x);
            img2 = reshape(img(start(1):stop(1), x2, start(3):stop(3)),...
                stop(1)-start(1)+1,stop(3)-start(3)+1);
            img = img1*abs(x2-point(2)-slice_offset)+img2*abs(x-point(2)-slice_offset);
        else
            img = img1;
        end
		img = img';
        [img,xs,ys]=resize_img(img,handles);
		H = image(xs,ys,img,'Parent',HA,'CDataMapping','scaled');
        axis off;
		daspect(HA,[1/handles.aspects(2) 1/handles.aspects(3) 1]);
		if handles.flipY == 1
			set(gca,'XDir','reverse');
		else
			set(gca,'XDir','normal');
		end
		if handles.flipZ == 1
			set(gca,'YDir','reverse');
		else
			set(gca,'YDir','normal');
        end

        % Draw edges
        if draw_edges && ~isempty(mask2d)
            PlotContourFunction1(HA,mask2d',handles);
        end
        
        % Draw the unmatched feature points
        if ~isempty(unmatched_points)
            for k = 1:size(unmatched_points,1)
                if unmatched_points(k,1)<start(1) || unmatched_points(k,1)>stop(1) || unmatched_points(k,3)<start(3) || unmatched_points(k,3)>stop(3); continue; end
                drawcircle(handles,unmatched_points(k,1)-start(1)+1,unmatched_points(k,3)-start(3)+1,unmatched_points(k,4),3,unmatched_point_indices(k));
            end
        end
        
        % Draw other feature points
        if ~isempty(other_matched_points)
            for k = 1:size(other_matched_points,1)
                if other_matched_points(k,1)<start(1) || other_matched_points(k,1)>stop(1) || other_matched_points(k,3)<start(3) || other_matched_points(k,3)>stop(3); continue; end
                drawcircle(handles,other_matched_points(k,1)-start(1)+1,other_matched_points(k,3)-start(3)+1,other_matched_points(k,4),2,other_matched_points_indices(k));
            end
            if draw_vector
                dxs = matched_points_diff(:,1);
                dys = matched_points_diff(:,3);
                xs0 = other_matched_points(:,1)-start(1)+1;
                ys0 = other_matched_points(:,3)-start(3)+1;
                hold on;quiver(HA,xs0,ys0,dxs,dys,0,'color',[0 1 0],'hittest','off');hold off;
            end
        end
        
		if handles.manual_verify_mode
			if all(handles.slice_offsets==0)
				% original
				drawcircle(handles,point(1)-start(1)+1,point(3)-start(3)+1,point(4),point_type,handles.indices(handles.nlandmark));
			else
				% manual
				drawcircle(handles,mpos(1)-start(1)+1,mpos(3)-start(3)+1,point(4),8,handles.indices(handles.nlandmark));
			end
		else
			% Draw the focused feature point
			if slice_offset==0
				if draw_vector;hold on;quiver(HA,point(1)-start(1)+1,point(3)-start(3)+1,point_diff(1),point_diff(3),0,'color',[1 0 0],'hittest','off');hold off;end
				drawcircle(handles,point(1)-start(1)+1,point(3)-start(3)+1,point(4),point_type,handles.indices(handles.nlandmark));
			end
			
			% Draw the manually placed position of the focused feature points
			if has_manual_position
				if abs(mpos(2)-point(2)-slice_offset)<0.1
					drawcircle(handles,mpos(1)-start(1)+1,mpos(3)-start(3)+1,point(4),8,handles.indices(handles.nlandmark));
				end
			end
		end
        
	case 3	% Transverse
        % Display the image
        z = min(max(round(point(3)+slice_offset),1),dim(3));
        sliceno = point(3);
        img1 = reshape(img(start(1):stop(1), start(2):stop(2), z),...
            stop(1)-start(1)+1,stop(2)-start(2)+1);
        if point(3)+slice_offset~= z && point(3)+slice_offset>= 1 && point(3)+slice_offset <= dim(3)
            z2 = z+sign(point(3)+slice_offset-z);
            img2 = reshape(img(start(1):stop(1), start(2):stop(2), z2),...
                stop(1)-start(1)+1,stop(2)-start(2)+1);
            img = img1*abs(z2-point(3)-slice_offset)+img2*abs(z-point(3)-slice_offset);
        else
            img = img1;
        end
        [img,xs,ys]=resize_img(img,handles);
		H = image(xs,ys,img,'Parent',HA,'CDataMapping','scaled');
        axis off;
        daspect(HA,[1/handles.aspects(1) 1/handles.aspects(2) 1]);
		if handles.flipX == 1
			set(gca,'XDir','reverse');
		else
			set(gca,'XDir','normal');
		end
		if handles.flipY == 1
			set(gca,'YDir','reverse');
		else
			set(gca,'YDir','normal');
        end
        
        % Draw edges
        if draw_edges && ~isempty(mask2d)
            PlotContourFunction1(HA,mask2d,handles);
        end
        
        %%% no transveral here
        % Draw the unmatched feature points
        if ~isempty(unmatched_points)
            for k = 1:size(unmatched_points,1)
                if unmatched_points(k,1)<start(1) || unmatched_points(k,1)>stop(1) || unmatched_points(k,2)<start(2) || unmatched_points(k,2)>stop(2); continue; end
                drawcircle(handles,unmatched_points(k,2)-start(2)+1,unmatched_points(k,1)-start(1)+1,unmatched_points(k,4),3,unmatched_point_indices(k));
            end
        end
        
        % Draw the other feature points
        if ~isempty(other_matched_points)
            for k = 1:size(other_matched_points,1)
                if other_matched_points(k,1)<start(1) || other_matched_points(k,1)>stop(1) || other_matched_points(k,2)<start(2) || other_matched_points(k,2)>stop(2); continue; end
                drawcircle(handles,other_matched_points(k,2)-start(2)+1,other_matched_points(k,1)-start(1)+1,other_matched_points(k,4),2,other_matched_points_indices(k));
            end
            if draw_vector
                dxs = matched_points_diff(:,2);
                dys = matched_points_diff(:,1);
                xs0 = other_matched_points(:,2)-start(2)+1;
                ys0 = other_matched_points(:,1)-start(1)+1;
                hold on;quiver(HA,xs0,ys0,dxs,dys,0,'color',[0 1 0],'hittest','off');hold off;
            end
        end
        
		if handles.manual_verify_mode
			if all(handles.slice_offsets==0)
				% original
				drawcircle(handles,point(2)-start(2)+1,point(1)-start(1)+1,point(4),point_type,handles.indices(handles.nlandmark));
			else
				% manual
				drawcircle(handles,mpos(2)-start(2)+1,mpos(1)-start(1)+1,point(4),8,handles.indices(handles.nlandmark));
			end
		else
			% Draw the focused feature point
			if slice_offset==0
				if draw_vector;hold on;quiver(HA,point(2)-start(2)+1,point(1)-start(1)+1,point_diff(2),point_diff(1),0,'color',[1 0 0],'hittest','off');hold off;end
				drawcircle(handles,point(2)-start(2)+1,point(1)-start(1)+1,point(4),point_type,handles.indices(handles.nlandmark));
			end
			
			% Draw the manually placed position of the focused feature points
			if has_manual_position
				if abs(mpos(3)-point(3)-slice_offset)<0.1
					drawcircle(handles,mpos(2)-start(2)+1,mpos(1)-start(1)+1,point(4),8,handles.indices(handles.nlandmark));
				end
			end
		end
        
end

set(handles.figure1,'colormap',map);
Draw_Text(HA,sliceno,handles.displaymode,slice_offset,handles);

if minv ~= maxv
	set(HA,'CLim',[minv maxv]);
end

if ishandle(H)
	set(H,'hittest','off');
end

children = get(handles.axes,'Children');
for k = 1:length(children)
    switch get(children(k),'Type')
        case {'line','rectangle','text'}
        otherwise
            set(children(k),'hittest','off');
    end
end
set(handles.axes,'buttonDownFcn',oldfcn);

return;
	
% --- Executes on slider movement.
function windowcenterslider_Callback(hObject, eventdata, handles)
% hObject    handle to windowcenterslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function windowcenterslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to windowcenterslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function windowcenterinput_Callback(hObject, eventdata, handles)
% hObject    handle to windowcenterinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of windowcenterinput as text
%        str2double(get(hObject,'String')) returns contents of windowcenterinput as a double

UpdateDisplay(handles);
return;


% --- Executes during object creation, after setting all properties.
function windowcenterinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to windowcenterinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function windowwidthinput_Callback(hObject, eventdata, handles)
% hObject    handle to windowwidthinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of windowwidthinput as text
%        str2double(get(hObject,'String')) returns contents of windowwidthinput as a double
UpdateDisplay(handles);
return;


% --- Executes during object creation, after setting all properties.
function windowwidthinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to windowwidthinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%----------------------------------------------------
function handles = init_window_controls(handles)
	minv = min(handles.image1(:));
	maxv = max(handles.image1(:));
	
    if isempty(handles.windowcenter)
        handles.windowcenter = ((maxv+minv)/2);
        handles.windowcenter = round(handles.windowcenter*10)/10;
    end
    
    if isempty(handles.windowwidth)
        handles.windowwidth = (maxv-minv);
        handles.windowwidth = round(handles.windowwidth*10)/10;
    end
	
	set(handles.windowcenterinput,'string',sprintf('%.1f',handles.windowcenter));
	set(handles.windowwidthinput,'string',sprintf('%.1f',handles.windowwidth));
    N = size(handles.landmarks,1);
	set(handles.key_slider,'min',1,'max',N,'Value',1,'sliderstep',[1/max(N-1,1) 10/max(N-1,1)]);
    set(handles.key_input,'String','1')

return;


function WindowButtonUpFcn_Callback(hObject, eventdata, handles)
set(handles.figure1, 'WindowButtonUpFcn', handles.WindowButtonUpFcn_save);
set(handles.figure1, 'WindowButtonMotionFcn', handles.WindowButtonMotionFcn_save);

return;


% --- Executes on mouse press over axes background.
function ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.WindowButtonUpFcn_save = get(handles.figure1,'WindowButtonUpFcn');

set(handles.figure1, 'WindowButtonUpFcn', 'matchgui(''WindowButtonUpFcn_Callback'',gcbo,[],guidata(gcbo))');
set(handles.figure1, 'WindowButtonMotionFcn', 'matchgui(''WindowButtonMotionFcn_Callback'',gcbo,[],guidata(gcbo))');

return;

% --- Executes on button press in figurewindowpushbutton.
function figurewindowpushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to figurewindowpushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

UpdateDisplay(handles,1);
return;


% --------------------------------------------------------------------
function Context_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Context_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Display_Options_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Display_Options_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Content_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Content_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Window_Levels_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Window_Levels_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Window_Level_Lung_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Window_Level_Lung_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.windowcenterinput,'String','450');
set(handles.windowwidthinput,'String','1000');
UpdateDisplay(handles);
return;

% --------------------------------------------------------------------
function Window_Level_Default_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Window_Level_Default_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if min(handles.image1(:)) < 0
	maxv = max(abs(handles.image1(:)));
	set(handles.windowcenterinput,'String','0');
	set(handles.windowwidthinput,'String',num2str(2*maxv));
else
	maxv = max(handles.image1(:));
	set(handles.windowcenterinput,'String',num2str(maxv/2));
	set(handles.windowwidthinput,'String',num2str(maxv));
end	
UpdateDisplay(handles);
return;



% --------------------------------------------------------------------
function Window_Level_Abdominal_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Window_Level_Abdominal_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% maxv = max(handles.image(:));
set(handles.windowcenterinput,'String','1000');
set(handles.windowwidthinput,'String','300');
UpdateDisplay(handles);
return;



% --------------------------------------------------------------------
function Window_Level_800_1600_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Window_Level_800_1600_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% maxv = max(handles.image1(:));
set(handles.windowcenterinput,'String','800');
set(handles.windowwidthinput,'String','1600');
UpdateDisplay(handles);
return;
% --------------------------------------------------------------------
% --------------------------------------------

function point_selected(src,event)
% src - the object that is the source of the event
% evnt - empty for this property

userdata = get(src,'UserData');
handles = guidata(userdata.figure1);

keyPressed = get(gcf, 'CurrentCharacter');
keyname = get(gcf, 'currentKey');


% fprintf('Index = %d, type = %d\n',userdata.index,userdata.type);
switch userdata.type
    case 1  % Matched point pair
        % Show the descriptors
        desc1=[];desc2=[];idx1=0;idx2=0;
        if ~isempty(handles.descriptors1) && ~isempty(handles.matched_points_indices_1) && handles.matched_points_indices_1(userdata.index)>0
            idx1 = handles.matched_points_indices_1(userdata.index);
            desc1 = handles.descriptors1(idx1,:);
        end
        if ~isempty(handles.descriptors2) && ~isempty(handles.matched_points_indices_2) && handles.matched_points_indices_2(userdata.index)>0
            idx2=handles.matched_points_indices_2(userdata.index);
            desc2 = handles.descriptors2(idx2,:);
        end
        plot_two_feature_descriptors(desc1,desc2,userdata.index,idx1,idx2);
        idxes = find(handles.slice_offsets ~=0);
        if ~isempty(idxes)
            handles.slice_offsets(idxes) = 0;
            UpdateDisplay(handles,idxes);
        end
        
%         feature1 = do_hog_on_points(handles.image1,8,2,handles.landmarks0(userdata.index,2:4));
%         feature2 = do_hog_on_points(handles.image2,8,2,handles.landmarks0(userdata.index,6:8));
%         hog1 = reshape(feature1,1,[]);
%         hog2 = reshape(feature2,1,[]);
%         figure(153);
%         subplot(2,1,1);
%         bar(hog1);
%         title(sprintf('HOG Image #1, point %d at %d',userdata.index,idx1));
%         subplot(2,1,2);
%         bar(hog2);
%         title(sprintf('HOG Image #2, point %d at %d',userdata.index,idx2));
%         
%         distance = pdist2(hog1,hog2);
%         distance = diag(distance);
% 
%         confidence = hog1 * hog2';        % Computes vector of dot products
%         angle = acos(confidence);  % Take inverse cosine and sort results
%         fprintf('Confidence = %.3f, angle = %.3f, distance=%.3f.\n',confidence,angle/pi*180,distance);
    case 2  % Other matched points
        n = find(handles.indices==userdata.index,1);
        set(handles.key_slider,'val',n);
        set(handles.key_input,'string',num2str(n));
        key_input_Callback(handles.key_input, [], handles);
    case 3  % Unmatched points
        if userdata.image_num == 1
            % On the first image
            if ~isempty(handles.descriptors1)
                idx1 = userdata.index;
                desc1 = handles.descriptors1(idx1,:);
                plot_two_feature_descriptors(desc1,[],userdata.index,idx1,0);
            end
        else
            % On the second image
            if ~isempty(handles.descriptors2)
                idx2=userdata.index;
                desc2 = handles.descriptors2(idx2,:);
                plot_two_feature_descriptors([],desc2,userdata.index,0,idx2);
            end
        end
    case 8  % manually place position
        mpos = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,userdata.image_num) ;
        landmark = handles.landmarks(handles.nlandmark,:);
        if userdata.image_num == 1
            point = landmark(2:4);
            offsets = round(mpos - point);
            handles.slice_offsets(1) = offsets(1);
            handles.slice_offsets(3) = offsets(2);
            handles.slice_offsets(5) = offsets(3);
            UpdateDisplay(handles,[1 3 5]);
        else
            point = landmark(6:8);
            offsets = round(mpos - point);
            handles.slice_offsets(2) = offsets(1);
            handles.slice_offsets(4) = offsets(2);
            handles.slice_offsets(6) = offsets(3);
            UpdateDisplay(handles,[2 4 6]);
        end
        guidata(handles.figure1,handles);
end

%%%
function v = getMATLABversion()
v = sscanf (version, '%d.%d.%d') ;
v = 10.^(0:-1:-(length(v)-1)) * v ;


% --------------------------------------------------------------------
function drawcircle(handles,x,y,s,type,index)
% type = 1  -   current point, which a good match
% type = 2  -   other matched points
% type = 3  -   unmatched points
% type = 4  -   current point, which a bad match
if handles.hide_all_features
    return;
end

aspects = [1 3;2 3;1 2];
aspects = handles.aspects(aspects(handles.displaymode,:));

% colors = lines(4);
colors = [...
    1 0.5 0;    % Current point
    0 1 0;      % SIFT
    1 1 1;      % Other features
    0 0 1;      
    1 0 0;      % Harris corners
    1 1 0;      % Edge corners
    0.5 0.5 0.5;
    0 1 1]; 
% colors = min(colors*1.5,1);

xshifts = [1 0 0 1 1 1 1 1];
yshifts = [0 -1 1 0 0 0 0 0];
if type == 2 && size(handles.landmarks,2) > 10
    % Feature type is provided at 11
    feature_type = handles.landmarks0(index,11);
    if feature_type > 1
%         type = type + feature_type + 2;
        c = colors(type + feature_type + 1,:);
    else
        c = colors(type,:);
    end
else
    % Feature type is provided
    c = colors(type,:);
end

x = double(x);
y = double(y);

userdata.type = type;
userdata.index = index;
userdata.figure1 = handles.figure1;
userdata.image_num = handles.leftright;

magnif=3./aspects;
pos=[x-magnif(1)*s, y-magnif(2)*s, magnif(1)*2*s, magnif(2)*2*s];
linewidth=1.5;
alpha = 0.5;
if getMATLABversion > 9
    c=[c alpha];
end
hl = rectangle('Position',pos,'linewidth',linewidth,'Curvature',[1 1],'EdgeColor',c,'Parent',handles.axes,'userdata',userdata,'ButtonDownFcn',@point_selected,'hittest','on');
xs = [x-magnif(1)*s/2  x+magnif(1)*s/2    x x             x];
ys = [y             y               y y+magnif(2)*s/2  y-magnif(2)*s/2];
% line(xs,ys,'Color',c);
hl = line(xs,ys,'Color',c,'linewidth',linewidth,'userdata',userdata,'ButtonDownFcn',@point_selected,'hittest','on','Parent',handles.axes);

switch get(gca,'XDir')
    case 'normal'
        xdir = 1;
    otherwise
        xdir = -1;
end

if handles.display_numbers==1 && exist('index','var')
    s = (magnif*s+2);
    text(x+s(1)*xshifts(type)*xdir,y+s(2)*yshifts(type),num2str(index),'color',c,'userdata',userdata,'ButtonDownFcn',@point_selected,'hittest','on');
end
% set(hl,'hittest','off');
return;


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isfield(handles,'timer')
	stop(handles.timer);
	delete(handles.timer);
end

return;


% --- Executes on key press over figure1 with no controls selected.
function figure1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
keyPressed = get(hObject, 'CurrentCharacter');
% keyValue = uint8(keyPressed);
keyname = get(hObject, 'currentKey');
modifier = get(hObject, 'CurrentModifier');
modifiers = length(modifier);
control=0;
shiftkey=0;
if modifiers
    for k = 1:modifiers
        switch modifier{k}
            case 'control'
                control = 1;
            case 'shift'
                shiftkey = 1;
        end
    end
end

switch keyPressed
% 	% options shortcut keys
% 	case 'P'	% show pixel info
% 		Options_Show_Pixel_Info_Menu_Item_Callback(handles.Options_Show_Pixel_Info_Menu_Item,eventdata,handles);
		
	% window level shortcut keys
	case {'L','l'}
		Window_Level_Lung_Menu_Item_Callback(handles.Window_Level_Lung_Menu_Item,eventdata,handles);
	case {'R','r'}
		Window_Level_Default_Menu_Item_Callback(handles.Window_Level_Default_Menu_Item,eventdata,handles);
	case {'o'}
		Window_Level_Abdominal_Menu_Item_Callback(handles.Window_Level_Abdominal_Menu_Item,eventdata,handles);
	case '8'
		Window_Level_800_1600_Menu_Item_Callback(handles.Window_Level_Abdominal_Menu_Item,eventdata,handles);
    case {'A','a'}
        Manul_Set_Point_Position(handles);
    case 'D'
        Delete_Manul_Point_Position(handles);
    case {'G','g'}
        if ~all(handles.slice_offsets == 0)
             Goto_Original_Position(handles);
        else
            Goto_Manul_Point_Position(handles);
        end
    case {'H','h'}
        set(handles.checkbox_hide_all_features,'value',1-get(handles.checkbox_hide_all_features,'value'));
        checkbox_hide_all_features_Callback(handles.checkbox_hide_all_features, [], handles);
    case {'O'}
        set(handles.checkbox_display_other_points,'value',1-get(handles.checkbox_display_other_points,'value'));
        checkbox_display_other_points_Callback(handles.checkbox_display_other_points, [], handles);
    case '1'
        if control == 0
            Scale_1_MenuItem_Callback(handles.Scale_2_MenuItem, [], handles);
        else
            set(handles.popupmenu_score,'value',1);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
        end
    case '2'
        if control == 0
            Scale_2_MenuItem_Callback(handles.Scale_2_MenuItem, [], handles);
        else
            set(handles.popupmenu_score,'value',2);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
        end
    case '3'
        if control == 0
            Scale_3_MenuItem_Callback(handles.Scale_2_MenuItem, [], handles);
        else
            set(handles.popupmenu_score,'value',3);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
        end
    case '4'
        if control == 1
            set(handles.popupmenu_score,'value',4);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
        end
    case '5'
        if control == 1
            set(handles.popupmenu_score,'value',5);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
        end
    case '6'
%         if control == 1
            set(handles.popupmenu_score,'value',6);
            popupmenu_score_Callback(handles.popupmenu_score,[],handles);
%         end
    case 'F'
        Refine_Feature_Position_MenuItem_Callback(handles.Refine_Feature_Position_MenuItem, [], handles);
    case {'B','b'}
        Refine_Bidirection_Menuitem_Callback(handles.Refine_Bidirection_Menuitem, eventdata, handles);
    case {'T','t'}
        set(handles.checkbox_good_match,'value',1-get(handles.checkbox_good_match,'value'));
        checkbox_good_match_Callback(handles.checkbox_good_match, [], handles);
    case {'U','u'}
        set(handles.checkbox_upsample,'value',1-get(handles.checkbox_upsample,'value'));
        checkbox_good_match_Callback(handles.checkbox_upsample, [], handles);
	otherwise
% 		disp(keyname)
% 		slicemax = get(handles.slicenoslider,'max');
% 		slicestep = min(max(1,round(slicemax/10)),10);
		switch lower(keyname)
% 			case {'pagedown'}
% 				sliceno = get(handles.slicenoslider,'Value');
% 				sliceno = min(sliceno + slicestep,slicemax);
% 				set(handles.slicenoslider,'Value',sliceno);
% 				slicenoslider_Callback(handles.slicenoslider, [], handles);				
% 			case {'pageup'}
% 				sliceno = get(handles.slicenoslider,'Value');
% 				sliceno = max(sliceno - slicestep,1);
% 				set(handles.slicenoslider,'Value',sliceno);
% 				slicenoslider_Callback(handles.slicenoslider, [], handles);				
			case {'downarrow'}
                e.VerticalScrollCount = -1;
                e.ShiftKey = shiftkey;
                figure1_WindowScrollWheelFcn([], e, handles);
			case {'rightarrow'}
                val = round(get(handles.key_slider,'value'));
                maxv = round(get(handles.key_slider,'max'));
                if shiftkey == 1
                    if control == 1
                        val = max(val+100,1);
                    else
                        val = min(val+10,maxv);
                    end
                else
                    val = min(val+1,maxv);
                end
%                 if val<maxv
%                     val=val+1;
%                 end
                set(handles.key_slider,'value',val);
                key_slider_Callback(handles.key_slider,[],handles);
			case {'uparrow'}
                e.VerticalScrollCount = 1;
                e.ShiftKey = shiftkey;
                figure1_WindowScrollWheelFcn([], e, handles);
			case {'leftarrow'}
                val = round(get(handles.key_slider,'value'));
                if shiftkey == 1
                    if control == 1
                        val = max(val-100,1);
                    else
                        val = max(val-10,1);
                    end
                else
                    val = max(val-1,1);
                end
%                 if val>1
%                     val=val-1;
%                 end
                set(handles.key_slider,'value',val);
                key_slider_Callback(handles.key_slider,[],handles);
% 			case {'home'}
% 				set(handles.slicenoslider,'Value',1);
% 				slicenoslider_Callback(handles.slicenoslider, [], handles);				
% 			case {'end'}
% 				set(handles.slicenoslider,'Value',slicemax);
% 				slicenoslider_Callback(handles.slicenoslider, [], handles);				
		end
end

function value = Check_MenuItem(hObject,FlipItOver)
if ~exist('FlipItOver','var')
	FlipItOver = 0;
end

checked = get(hObject,'Checked');
switch checked
	case 'on'
		if FlipItOver == 0
			value = 1;
		else
			set(hObject,'Checked','off');
			value = 0;
		end
	case 'off'
		if FlipItOver == 0
			value = 0;
		else
			set(hObject,'Checked','on');
			value = 1;
		end
end

return;


function vecout=normalized2pixel(vec,H)
if ~exist('H','var')
	pos = get(gcf,'Position');
else
	pos = get(H,'Position');
end
vecout = vec;
vecout(1:2:end) = vecout(1:2:end)*pos(3);
vecout(2:2:end) = vecout(2:2:end)*pos(4);
return;



% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% matchgui('figure1_WindowButtonMotionFcn',gcbo,[],guidata(gcbo))
% matchgui('figure1_WindowButtonUpFcn',gcbo,[],guidata(gcbo))

if strcmp(get(gcf,'SelectionType'),'alt') %
    pos=get(gcf,'currentpoint');
    set(handles.Content_Menu,'position',[pos(1,1), pos(1,2)],'visible','on')
end
return;

% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.figure1, 'WindowButtonUpFcn', handles.WindowButtonUpFcn_save);
set(handles.figure1, 'WindowButtonMotionFcn', handles.WindowButtonMotionFcn_save);

return;



% --------------------------------------------------------------------
function Flip_X_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Flip_X_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.flipX = Check_MenuItem(hObject,1);
guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --------------------------------------------------------------------
function Flip_Y_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Flip_Y_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.flipY = Check_MenuItem(hObject,1);
guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --------------------------------------------------------------------
function Flip_Z_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Flip_Z_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.flipZ = Check_MenuItem(hObject,1);
guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --------------------------------------------------------------------
function SetRotation(handles,degree)
if handles.rotation ~= degree
	handles.rotation=degree;
	set(handles.Rotate_0_Menu_Item,'checked','off');
	set(handles.Rotate_90_Menu_Item,'checked','off');
	set(handles.Rotate_180_Menu_Item,'checked','off');
	set(handles.Rotate_270_Menu_Item,'checked','off');
	switch degree
		case 0
			set(handles.Rotate_0_Menu_Item,'checked','on');
		case 90
			set(handles.Rotate_90_Menu_Item,'checked','on');
		case 180
			set(handles.Rotate_180_Menu_Item,'checked','on');
		case 270
			set(handles.Rotate_270_Menu_Item,'checked','on');
	end
	guidata(handles.figure1,handles);
	UpdateDisplay(handles);
end
return;

% --------------------------------------------------------------------
function Rotate_0_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Rotate_0_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SetRotation(handles,0);

% --------------------------------------------------------------------
function Rotate_90_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Rotate_90_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SetRotation(handles,90);

% --------------------------------------------------------------------
function Rotate_180_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Rotate_180_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SetRotation(handles,180);

% --------------------------------------------------------------------
function Rotate_270_Menu_Item_Callback(hObject, eventdata, handles)
% hObject    handle to Rotate_270_Menu_Item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SetRotation(handles,270);


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on slider movement.
function key_slider_Callback(hObject, eventdata, handles)
% hObject    handle to key_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
val = round(get(hObject,'value'));
handles.nlandmark = val;
set(handles.key_input,'String',num2str(val));
handles.slice_offsets=handles.slice_offsets*0;
guidata(handles.figure1,handles);
[val1,val2]=Goto_Manul_Point_Position(handles);
if ~val1
    UpdateDisplay(handles,[1 3 5]);
end
if ~val2
    UpdateDisplay(handles,[2 4 6]);
end

% --- Executes during object creation, after setting all properties.
function key_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to key_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
% set(hObject,'max',100,'Value',1);



function key_input_Callback(hObject, eventdata, handles)
% hObject    handle to key_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of key_input as text
%        str2double(get(hObject,'String')) returns contents of key_input as a double
val = round(str2double(get(hObject,'String')));
val = min(max(1,val),size(handles.landmarks,1));
set(handles.key_slider,'val',val);
set(handles.key_input,'string',num2str(val));
handles.nlandmark = val;
handles.slice_offsets=handles.slice_offsets*0;
guidata(handles.figure1,handles);
[val1,val2]=Goto_Manul_Point_Position(handles);
if ~val1
    UpdateDisplay(handles,[1 3 5]);
end
if ~val2
    UpdateDisplay(handles,[2 4 6]);
end

% --- Executes during object creation, after setting all properties.
function key_input_CreateFcn(hObject, eventdata, handles)
% hObject    handle to key_input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on slider movement.
function zoom_slider_Callback(hObject, eventdata, handles)
% hObject    handle to zoom_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
UpdateDisplay(handles);

% --- Executes during object creation, after setting all properties.
function zoom_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoom_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
% set(hObject,'max',50,'min',4,'value',50);
maxzoom = 16;
set(hObject,'max',maxzoom,'min',4,'value',maxzoom,'SliderStep',[1/maxzoom,1/maxzoom]);




function match_quality_Callback(hObject, eventdata, handles)
% hObject    handle to match_quality (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of match_quality as text
%        str2double(get(hObject,'String')) returns contents of match_quality as a double


% --- Executes during object creation, after setting all properties.
function match_quality_CreateFcn(hObject, eventdata, handles)
% hObject    handle to match_quality (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dim=mysize(m)

dim = size(m);
if length(dim) == 2
	dim = [dim 1];
end



% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
sel = get(hObject,'value');
if sel ~= handles.sorting_method
    strs = get(hObject,'string');
    handles.sorting_method = sel;
    current_index = handles.indices(round(get(handles.key_slider,'value')));
    switch( lower(strs{sel}) )
        case 'quality'
            [~,orderI]=sort(handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case {'point distance','distance'}
%             dists = sqrt((handles.landmarks0(:,4)-handles.landmarks0(:,8)).^2+(handles.landmarks0(:,3)-handles.landmarks0(:,7)).^2+(handles.landmarks0(:,2)-handles.landmarks0(:,6)).^2);
            dists = sqrt((handles.landmarks0_centered(:,4)-handles.landmarks0_centered(:,8)).^2*handles.aspects_2(3)+(handles.landmarks0_centered(:,3)-handles.landmarks0_centered(:,7)).^2*handles.aspects_2(2)+...
                (handles.landmarks0_centered(:,2)-handles.landmarks0_centered(:,6)).^2*handles.aspects_2(1));
            [~,orderI]=sort(dists);
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'size'
            [~,orderI]=sort(handles.landmarks0(:,5));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'axial on 1'
            [~,orderI]=sort(handles.landmarks0(:,4)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'coronal on 1'
            [~,orderI]=sort(handles.landmarks0(:,2)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'sagittal on 1'
            [~,orderI]=sort(handles.landmarks0(:,3)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'axial on 2'
            [~,orderI]=sort(handles.landmarks0(:,8)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'coronal on 2'
            [~,orderI]=sort(handles.landmarks0(:,6)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'sagittal on 2'
            [~,orderI]=sort(handles.landmarks0(:,7)*1000-handles.landmarks0(:,10));
            handles.indices = orderI;
            handles.landmarks(:,:)=handles.landmarks0(orderI,:);
        case 'tre'
            if ~all(isnan(handles.manually_placed_positions(:)))
                dists1 = sqrt(sum((handles.manually_placed_positions(:,:,1)-handles.landmarks0(:,2:4)).^2.*repmat(handles.aspects_2,[size(handles.landmarks0,1) 1]),2));
                dists2 = sqrt(sum((handles.manually_placed_positions(:,:,2)-handles.landmarks0(:,6:8)).^2.*repmat(handles.aspects_2,[size(handles.landmarks0,1) 1]),2));
				dists1(isnan(dists1))=0;
				dists2(isnan(dists2))=0;
                dists = max(dists1,dists2);
                [~,orderI]=sort(dists);
                handles.indices = orderI;
                handles.landmarks(:,:)=handles.landmarks0(orderI,:);
			else
				orderI = 1:size(handles.landmarks0,1);
            end
        otherwise
            orderI = 1:size(handles.landmarks0,1);
            handles.indices = orderI;
            handles.landmarks=handles.landmarks0;
    end
    handles.nlandmark=find(orderI==current_index,1);
    set(handles.key_input,'string',num2str(handles.nlandmark));
    set(handles.key_slider,'value',handles.nlandmark);
    guidata(handles.figure1,handles);
    UpdateDisplay(handles);
end


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_display_other_points.
function checkbox_display_other_points_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_display_other_points (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_display_other_points
UpdateDisplay(handles);


% --- Executes on button press in checkbox_upsample.
function checkbox_upsample_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_upsample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_upsample
UpdateDisplay(handles);


% --- Executes on button press in checkbox_display_additional_points.
function checkbox_display_additional_points_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_display_additional_points (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_display_additional_points
UpdateDisplay(handles);


% --- Executes on scroll wheel click while the figure is in focus.
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)

modifier = get(hObject, 'CurrentModifier');
modifiers = length(modifier);
control=0;
shiftkey=0;
if modifiers
    for k = 1:modifiers
        switch modifier{k}
            case 'control'
                control = 1;
            case 'shift'
                shiftkey = 1;
        end
    end
end

if isfield(eventdata,'ShiftKey')
    shiftkey=eventdata.ShiftKey;
end

N = length(handles.axes_handles);
for k = 1:N
    haxes = handles.axes_handles(k);
    current_mouse_point = round(get(haxes, 'currentPoint'));
    xa = get(haxes,'xlim');
    ya = get(haxes,'ylim');
    if current_mouse_point(1,1) >= xa(1) && current_mouse_point(1,1) <= xa(2) && current_mouse_point(1,2) >= ya(1) && current_mouse_point(1,2) <= ya(2)
        %         fprintf('Mouse is in axes %d\n',k);
        if shiftkey
            k2 = floor((k+1)/2)*2-1;
            handles.slice_offsets(k2)=handles.slice_offsets(k2)+sign(eventdata.VerticalScrollCount);
            handles.slice_offsets(k2+1)=handles.slice_offsets(k2+1)+sign(eventdata.VerticalScrollCount);
            guidata(handles.figure1,handles);
            UpdateDisplay(handles,[k2 k2+1]);
        else
            handles.slice_offsets(k)=handles.slice_offsets(k)+sign(eventdata.VerticalScrollCount);
            guidata(handles.figure1,handles);
            UpdateDisplay(handles,k);
        end
        break;
    end
end

function Draw_Text(HA,sliceno,displaymode,offset,handles)
xlim = get(HA,'xlim');
ylim = get(HA,'ylim');
sliceno=sliceno+offset;

dir_strings = {'Cor','Sag','Tra'};
dstr = dir_strings{displaymode};

switch get(HA,'XDir')
    case 'normal'
        xdir = 1;
        x = xlim(1);
    otherwise
        xdir = -1;
        x = xlim(2);
end

switch get(HA,'YDir')
    case 'normal'
        ydir = 1;
        y = ylim(2);
        ylower = ylim(1);
    otherwise
        ydir = -1;
        y = ylim(1);
        ylower = ylim(2);
end

x2 = x+abs(diff(xlim))*0.02*xdir;
y2 = y-abs(diff(ylim))*0.05*ydir;

if handles.manual_verify_mode
	textstr = sprintf('%s:%d',dstr,round(sliceno));
else
	if offset>0
		textstr = sprintf('%s:%.1f(%.1f+%.1f)',dstr,sliceno,sliceno-offset,offset);
	elseif offset<0
		textstr = sprintf('%s:%.1f(%.1f%.1f)',dstr,sliceno,sliceno-offset,offset);
	else
		textstr = sprintf('%s:%.1f',dstr,sliceno);
	end
end
text(x2,y2,textstr,'FontSize',12,'color',[1 0.5 0.5],'FontWeight','bold','hittest','off','Units','data','hittest','off');




% --- Executes on button press in checkbox_display_number.
function checkbox_display_number_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_display_number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_display_number
handles.display_numbers = get(hObject,'value');
guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --- Executes on button press in checkbox_good_match.
function checkbox_good_match_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_good_match (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_good_match

% handles.good_landmark_flags(handles.indices(handles.nlandmark)) = 1-handles.good_landmark_flags(handles.indices(handles.nlandmark));
handles.good_landmark_flags(handles.indices(handles.nlandmark)) = get(handles.checkbox_good_match,'value');
guidata(handles.figure1,handles);
% fprintf('Set good_match flag at %d (%d) to %d\n',handles.nlandmark,handles.indices(handles.nlandmark),handles.good_landmark_flags(handles.indices(handles.nlandmark)));
UpdateDisplay(handles);
% set(handles.checkbox_good_match,'value',handles.good_landmark_flags(handles.indices(handles.nlandmark)));

% --- Executes on button press in checkbox_show_vector.
function checkbox_show_vector_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_show_vector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_show_vector
UpdateDisplay(handles);



% --- Executes on button press in checkbox_show_edges.
function checkbox_show_edges_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_show_edges (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_show_edges
UpdateDisplay(handles);


% --------------------------------------------
function strnums = PlotContourFunction1(HA,mask,handles)
linecolormap = lines(64);
linecolormap = min(linecolormap*2,1);
% linetypes = {'-','-.','--'};
linetypes = {'-','-','-'};
% linetype = ':';
% linewidth = 5;
linewidth = 1;
mask_mode = handles.mask_mode;
strnums = [];
if get(handles.checkbox_upsample,'value')==0
    zoom = 1;
else
    zoom = 4;
end
alpha_val = 1;
% alpha_val = 0.6;
switch lower(mask_mode)
    case 'bit'
        if max(mask(:)) == 0
            return;
        end
        
        set(HA,'NextPlot','Add');
        NC = floor(log2(double(max(mask(:)))))+1;
        for k = 1:NC
            %             maskbit = (mask >= 2^(k-1));
            maskbit = bitget(mask,k);
            if max(maskbit(:)) > 0 && (handles.mask_is_generated_from_contours == false || handles.contours(k).Visible==1)
                strnums = [strnums k];
                cs = contourd(double(maskbit),[0.5 0.5]);
                if handles.mask_is_generated_from_contours == false
                    % Draw mask
                    plot_contourd(HA,cs,'LineStyle',linetypes{mod(k-1,3)+1},'Color',linecolormap(k,:),'LineWidth',linewidth);
                else
                    if handles.displaymode ~= 3
                        % Draw mask generated from the contours
                        % Not to draw in Axial view, for which contours are drawn differently
                        %                         if handles.contours(k).Fill == 1
                        %                             % Draw the shade
                        %                             plot_contourd(HA,cs,'LineStyle',handles.contours(k).Style,'Color',handles.contours(k).Color,'LineWidth',handles.contours(k).Thickness);
                        %                         end
                        plot_contourd(HA,cs,'LineStyle',handles.contours(k).Style,'Color',handles.contours(k).Color,'LineWidth',handles.contours(k).Thickness);
                    end
                end
                % 						plot_contourd(HA,cs,'LineStyle',linetypes{mod(k-1,3)+1},'Color',linecolormap(ceil(k/3),:),'LineWidth',linewidth);
                % 		    			contour(HA,maskbit,[1 1],linetype,'Color',linecolormap(k,:),'LineWidth',linewidth);
            end
        end
        set(HA,'NextPlot','Replace');
    case 'edge'
        set(HA,'NextPlot','Add');
        NC = length(mask);
        Ncolor = size(linecolormap,1);
        for k = 1:NC
            edge = mask{k};
            if ~isempty(edge)
                %                 plot(HA,edge.xs,edge.ys,'LineStyle',linetypes{mod(k-1,3)+1},'Color',linecolormap(mod(k-1,Ncolor)+1,:),'LineWidth',linewidth);
                %                 fprintf('Segment %d: %d points.\n',k,length(edge.xs));
                plot(HA,edge.xs,edge.ys,'.','Color',linecolormap(mod(k-1,Ncolor)+1,:),'LineWidth',linewidth);
            end
        end
        set(HA,'NextPlot','Replace');
    case 'surface'
        % To display the surface as pixels
        if max(mask(:)) == 0
            return;
        end
        
        set(HA,'NextPlot','Add');
        %         NC = max(mask(:));
        Ncolor = size(linecolormap,1);
        unique_segments = unique(mask(:));
        unique_segments = unique_segments(unique_segments~=0);
        dim = size(mask);
        xs = 1:dim(2); ys = 1:dim(1);
        if zoom == 2
            mask = round(imresize(mask,2.0));
        elseif zoom == 4
            mask = round(imresize(mask,4.0));
        end
        maskr = single(mask)*0;
        maskg = single(mask)*0;
        maskb = single(mask)*0;
        for k = unique_segments'
            color_vals = linecolormap(mod(k-1,Ncolor)+1,:);
            maskr(mask == k) = color_vals(1);
            maskg(mask == k) = color_vals(2);
            maskb(mask == k) = color_vals(3);
        end
        if zoom == 2
%             maskr = imresize(maskr,2.0);
%             maskg = imresize(maskg,2.0);
%             maskb = imresize(maskb,2.0);
%             mask = round(imresize(mask,2.0));
            xs=[xs-0.25;xs+0.25]; xs=xs(:)';
            ys=[ys-0.25;ys+0.25]; ys=ys(:)';
        elseif zoom == 4
%             maskr = imresize(maskr,4.0);
%             maskg = imresize(maskg,4.0);
%             maskb = imresize(maskb,4.0);
%             mask = imresize(mask,4.0);
            xs=[xs-0.375;xs-0.125;xs+0.125;xs+0.25]; xs=xs(:)';
            ys=[ys-0.375;ys-0.125;ys+0.125;ys+0.25]; ys=ys(:)';
        end
        hold on;
        maskc = cat(3,maskr,maskg,maskb);
%         h=image(HA,xs,ys,maskc);
        h=image(xs,ys,maskc,'parent',HA);
        hold off;
        set(h,'alphadata',(mask>0)*alpha_val,'hittest','off');
        
        set(HA,'NextPlot','Replace');
    otherwise
        if max(mask(:)) == 0
            return;
        end
        
        set(HA,'NextPlot','Add');
        %         NC = max(mask(:));
        Ncolor = size(linecolormap,1);
        unique_segments = unique(mask(:));
        for k = unique_segments'
            maskbit = (mask == k);
            if max(maskbit(:)) > 0
                %                 fprintf('Segment %d: %d points.\n',k,sum(maskbit(:)));
                cs = contourd(double(maskbit),[0.5 0.5]);
                plot_contourd(HA,cs,'LineStyle',linetypes{mod(k-1,3)+1},'Color',linecolormap(mod(k-1,Ncolor)+1,:),'LineWidth',linewidth);
                % 						plot_contourd(HA,cs,'LineStyle',linetypes{mod(k-1,3)+1},'Color',linecolormap(ceil(k/3),:),'LineWidth',linewidth);
                % 		    			contour(HA,maskbit,[1 1],linetype,'Color',linecolormap(k,:),'LineWidth',linewidth);
            end
        end
        set(HA,'NextPlot','Replace');
end


% --- Executes on button press in checkbox_find_edges.
function checkbox_find_edges_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_find_edges (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_find_edges


% --------------------------------------------------------------------
function Load_Manual_Flags_Callback(hObject, eventdata, handles)
% hObject    handle to Load_Manual_Flags (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename,pathname] = uigetfile('*.mat');
if filename == 0
    % user cancelled
    return;
end

load(fullfile(pathname,filename),'good_landmark_flags','manually_placed_positions','landmark_scores');
if ~exist('good_landmark_flags','var') || isempty(good_landmark_flags)
    %
elseif length(good_landmark_flags) ~= size(handles.landmarks,1)
    fprintf('Number of landmark flags does not match to the number of landmarks in this dataset. Loading is not successfully.\n');
else
    handles.good_landmark_flags=good_landmark_flags;
end

if ~exist('manually_placed_positions','var') || isempty(manually_placed_positions)
    %
elseif size(manually_placed_positions,1) ~= size(handles.landmarks,1)
    fprintf('Number of manually place landmark positions does not match to the number of landmarks in this dataset. Loading is not successfully.\n');
else
    handles.manually_placed_positions = manually_placed_positions;
end

if ~exist('landmark_scores','var') || isempty(landmark_scores)
    %
elseif length(landmark_scores) ~= length(handles.landmark_scores)
    fprintf('Number of landmark_scores does not match to the number of landmarks in this dataset. Loading is not successfully.\n');
else
    handles.landmark_scores=landmark_scores;
end


guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --------------------------------------------------------------------
function Save_Manual_Flags_Callback(hObject, eventdata, handles)
% hObject    handle to Save_Manual_Flags (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename,pathname] = uiputfile('*.mat');
if filename == 0
    % user cancelled
    return;
end

good_landmark_flags=handles.good_landmark_flags;
manually_placed_positions=handles.manually_placed_positions;
landmark_scores = handles.landmark_scores;
save(fullfile(pathname,filename),'good_landmark_flags','manually_placed_positions','landmark_scores');

% ---
function Manul_Set_Point_Position(handles)
landmark = handles.landmarks(handles.nlandmark,:);
points{1} = landmark(2:5);
points{2} = landmark(6:9);

N = length(handles.axes_handles);
for k = 1:N
    haxes = handles.axes_handles(k);
    current_mouse_point = get(haxes, 'currentPoint');
    xa = get(haxes,'xlim');
    ya = get(haxes,'ylim');
    if current_mouse_point(1,1) >= xa(1) && current_mouse_point(1,1) <= xa(2) && current_mouse_point(1,2) >= ya(1) && current_mouse_point(1,2) <= ya(2) 
        switch k
            case {1,3,5}
                pidx=1;
            otherwise
                pidx=2;
        end
        point = points{pidx};
        zoomfactor=2^(get(handles.zoom_slider,'value')/2);
        maxscale=2;
        start=max(1,round(point(1:3)-zoomfactor*maxscale./handles.aspects));
        stop=min(round(point(1:3)+zoomfactor*maxscale./handles.aspects),handles.dim);

        switch k
            case {1,2}  % coronal
                x=current_mouse_point(1,1)+start(2)-1;
                y=point(1)+handles.slice_offsets(k);
                z=current_mouse_point(1,2)+start(3)-1;
            case {3,4}  % sagittal
                x=point(2)+handles.slice_offsets(k);
                y=current_mouse_point(1,1)+start(1)-1;
                z=current_mouse_point(1,2)+start(3)-1;
            otherwise % axial
                x=current_mouse_point(1,1)+start(2)-1;
                y=current_mouse_point(1,2)+start(1)-1;
                z=point(3)+handles.slice_offsets(k);
        end
        
        fprintf('To manually place point %d-%d at x=%.1f, y=%.1f, z=%.1f\n ',handles.nlandmark,pidx,x,y,z);
        handles.manually_placed_positions(handles.indices(handles.nlandmark),:,pidx) = [y x z];
        switch k
            case {1,3,5}
                handles.slice_offsets([1 3 5]) = round([y x z] - handles.landmarks(handles.nlandmark,2:4));
            otherwise
                handles.slice_offsets([2 4 6]) = round([y x z] - handles.landmarks(handles.nlandmark,6:8));
        end
        guidata(handles.figure1,handles);
        Goto_Manul_Point_Position(handles);
%         UpdateDisplay(handles);
    end
end

%
function Delete_Manul_Point_Position(handles)
handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1) = [nan nan nan];
handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2) = [nan nan nan];
handles.slice_offsets = [0 0 0 0 0 0];
guidata(handles.figure1,handles);
UpdateDisplay(handles);

%
function [success1,success2]=Goto_Manul_Point_Position(handles)
landmark = handles.landmarks(handles.nlandmark,:);
mpos1=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
success1 = false;
success2 = false;
if ~any(isnan(mpos1))
    point = landmark(2:4);
%     offsets = round(mpos1) - round(point);
    offsets = round((mpos1 - point)*10)/10;
    handles.slice_offsets(1) = offsets(1);
    handles.slice_offsets(3) = offsets(2);
    handles.slice_offsets(5) = offsets(3);
    UpdateDisplay(handles,[1 3 5]);
    guidata(handles.figure1,handles);
    success1=true;
end

mpos2=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
if ~any(isnan(mpos2))
    point = landmark(6:8);
    %             offsets = round(mpos2) - round(point);
    offsets = round((mpos2 - point)*10)/10;
    handles.slice_offsets(2) = offsets(1);
    handles.slice_offsets(4) = offsets(2);
    handles.slice_offsets(6) = offsets(3);
    UpdateDisplay(handles,[2 4 6]);
    guidata(handles.figure1,handles);
    success2=true;
end

% 
function Goto_Original_Position(handles)
if ~all(handles.slice_offsets == 0)
    idxes = find(handles.slice_offsets~=0);
    handles.slice_offsets = [0 0 0 0 0 0];
    guidata(handles.figure1,handles);
	if ~handles.manual_verify_mode
		UpdateDisplay(handles,idxes);
	else
		UpdateDisplay(handles);
	end
end

% --------------------------------------------------------------------
function Add_Manual_Position_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Add_Manual_Position_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Delete_Manual_Position_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Delete_Manual_Position_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Delete_Manul_Point_Position(handles);

% --------------------------------------------------------------------
function Goto_Manual_Position_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Goto_Manual_Position_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Goto_Manul_Point_Position(handles);

% --------------------------------------------------------------------
function Goto_Original_Position_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Goto_Original_Position_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Goto_Original_Position(handles);

% --------------------------------------------------------------------
function Manual_Confirmation_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Manual_Confirmation_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mpos1=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
mpos2=handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
if all(isnan(mpos1)) && all(isnan(mpos2))
    set(handles.Delete_Manual_Position_MenuItem,'enable','off');
    set(handles.Goto_Manual_Position_MenuItem,'enable','off');
else
    set(handles.Delete_Manual_Position_MenuItem,'enable','on');
    set(handles.Goto_Manual_Position_MenuItem,'enable','on');
end

if all(handles.slice_offsets==0)
    set(handles.Goto_Original_Position_MenuItem,'enable','off');
else
    set(handles.Goto_Original_Position_MenuItem,'enable','on');
end

% --------------------------------------------------------------------
function Previous_Bad_Match_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Previous_Bad_Match_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.nlandmark >1
    good_landmark_flags = handles.good_landmark_flags(handles.indices);
    idx = find(good_landmark_flags(1:(handles.nlandmark-1))==0,1,'last');
    if ~isempty(idx)
        set(handles.key_input,'string',num2str(idx));
        key_input_Callback(handles.key_input, [], handles);
    end
end

% --------------------------------------------------------------------
function Next_Bad_Match_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Bad_Match_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.nlandmark < length(handles.indices)
    good_landmark_flags = handles.good_landmark_flags(handles.indices);
    idx = find(good_landmark_flags((handles.nlandmark+1):length(handles.indices))==0,1,'first');
    if ~isempty(idx)
        set(handles.key_input,'string',num2str(handles.nlandmark+idx));
        key_input_Callback(handles.key_input, [], handles);
    end
end


% --------------------------------------------------------------------
function Previous_Manual_Feature_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Previous_Manual_Feature_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.nlandmark >1
    mpos1s=sum(handles.manually_placed_positions(handles.indices,:,1),2);
    mpos2s=sum(handles.manually_placed_positions(handles.indices,:,2),2);
    idx = find(~isnan(mpos1s(1:(handles.nlandmark-1))) + ~isnan(mpos2s(1:(handles.nlandmark-1))) > 0,1,'last');
    if ~isempty(idx)
        handles.nlandmark = idx;
        set(handles.key_input,'string',num2str(idx));
        key_input_Callback(handles.key_input, [], handles);
        handles = guidata(handles.figure1);
        Goto_Manul_Point_Position(handles);
    end
end


% --------------------------------------------------------------------
function Next_Manual_Feature_MeanItem_Callback(hObject, eventdata, handles)
% hObject    handle to Next_Manual_Feature_MeanItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if handles.nlandmark < length(handles.indices)
    mpos1s=sum(handles.manually_placed_positions(handles.indices,:,1),2);
    mpos2s=sum(handles.manually_placed_positions(handles.indices,:,2),2);
    idx = find(~isnan(mpos1s((handles.nlandmark+1):length(handles.indices))) + ~isnan(mpos2s((handles.nlandmark+1):length(handles.indices))) > 0,1,'first');
    if ~isempty(idx)
        set(handles.key_input,'string',num2str(idx+handles.nlandmark));
        key_input_Callback(handles.key_input, [], handles);
        handles = guidata(handles.figure1);
        Goto_Manul_Point_Position(handles);
    end
end

% --------------------------------------------------------------------
function Scale_1_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Scale_1_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(handles.Scale_1_MenuItem,'checked') , 'on')==0
    set(handles.Scale_1_MenuItem,'checked','on') ;
    set(handles.Scale_2_MenuItem,'checked','off') ;
    set(handles.Scale_3_MenuItem,'checked','off') ;
    handles.feature_scale=1;
    guidata(handles.figure1,handles);
end

% --------------------------------------------------------------------
function Scale_2_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Scale_2_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(handles.Scale_2_MenuItem,'checked') , 'on')==0
    set(handles.Scale_1_MenuItem,'checked','off') ;
    set(handles.Scale_2_MenuItem,'checked','on') ;
    set(handles.Scale_3_MenuItem,'checked','off') ;
    handles.feature_scale=2;
    guidata(handles.figure1,handles);
end


% --------------------------------------------------------------------
function Scale_3_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Scale_3_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(handles.Scale_3_MenuItem,'checked') , 'on')==0
    set(handles.Scale_1_MenuItem,'Checked','off') ;
    set(handles.Scale_2_MenuItem,'checked','off') ;
    set(handles.Scale_3_MenuItem,'checked','on') ;
    handles.feature_scale=3;
    guidata(handles.figure1,handles);
end


% --------------------------------------------------------------------
function Refine_Feature_Position_MenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Feature_Position_MenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
N = length(handles.axes_handles);
axe_num=nan;
for k = 1:N
    haxes = handles.axes_handles(k);
    current_mouse_point = round(get(haxes, 'currentPoint'));
    xa = get(haxes,'xlim');
    ya = get(haxes,'ylim');
    if current_mouse_point(1,1) >= xa(1) && current_mouse_point(1,1) <= xa(2) && current_mouse_point(1,2) >= ya(1) && current_mouse_point(1,2) <= ya(2) 
        %         fprintf('Mouse is in axes %d\n',k);
        axe_num = k;
        break;
    end
end

if isnan(axe_num)
    axe_num=1;
%     return;
end

landmark = handles.landmarks(handles.nlandmark,:);
% scale0 = sum(landmark(5)+landmark(9))/2;
% iterations=100;
subtract_min = strcmpi(get(handles.Subtract_min_value_menu_item,'checked'),'on');
normalize_max= strcmpi(get(handles.Normalize_max_value_menu_item,'checked'),'on');
apply_gaussian = strcmpi(get(handles.Apply_Gaussian_Weighting_menu_item,'checked'),'on');

if handles.PositionRefineBidirectional == 0
    imgnum = mod(axe_num+1,2)+1;
    mpos = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
    if ~all(isnan(mpos))
        landmark(2:4)=mpos;
    end
    mpos = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
    if ~all(isnan(mpos))
        landmark(6:8)=mpos;
    end
    mpos = landmark((imgnum-1)*4+(2:4));
	handles.aspects
	args = {'method',handles.PositionRefineMethod,'scale',handles.feature_scale+1,'dv_amplify',1,'to_subtract_minimal_intensity',subtract_min,'normalize_max_intensity',...
		normalize_max,'apply_gaussian',apply_gaussian,'xzratio',handles.aspects(3)/handles.aspects(1)};
    switch imgnum
        case 1
            mpos2 = refine_pair_positions_by_region_gradient_v5_symmetric(handles.image1,handles.image2,landmark,args{:});
            mpos2 = mpos2(2:4);
        otherwise %2
            landmark2 = landmark;
            landmark2(2:5)=landmark(6:9);
            landmark2(6:9)=landmark(2:5);
            mpos2 = refine_pair_positions_by_region_gradient_v5_symmetric(handles.image2,handles.image1,landmark2,args{:});
            mpos2 = mpos2(2:4);
    end
    handles.manually_placed_positions(handles.indices(handles.nlandmark),:,imgnum) = mpos2;
    dist = sqrt(sum((mpos-mpos2).^2.*handles.aspects_2));
    fprintf('Changing position from (%.1f, %.1f, %.1f) to (%.1f, %.1f, %.1f)\nDist = %.2f\n',mpos(1),mpos(2),mpos(3),mpos2(1),mpos2(2),mpos2(3),dist);
else
    mpos1 = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1);
    if ~all(isnan(mpos1))
        landmark(2:4)=mpos1;
    else
        mpos1=landmark(2:4);
    end
    mpos2 = handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2);
    if ~all(isnan(mpos2))
        landmark(6:8)=mpos2;
    else
        mpos2=landmark(6:8);
    end
    mpos_new = refine_pair_positions_by_region_gradient_v5_symmetric(handles.image1,handles.image2,landmark,'method',handles.PositionRefineMethod,...
         'scale',handles.feature_scale+1,'dv_amplify',1,'to_subtract_minimal_intensity',subtract_min,'normalize_max_intensity',normalize_max,'apply_gaussian',apply_gaussian,...
         'use_both_gradient',true,'bi_dir',true,'xzratio',handles.aspects(3)/handles.aspects(1));
    handles.manually_placed_positions(handles.indices(handles.nlandmark),:,1) = mpos_new(2:4);
    handles.manually_placed_positions(handles.indices(handles.nlandmark),:,2) = mpos_new(6:8);
    dist1 = sqrt(sum((mpos1-mpos_new(2:4)).^2.*handles.aspects_2));
    dist2 = sqrt(sum((mpos2-mpos_new(6:8)).^2.*handles.aspects_2));
    fprintf('Changing position 1 from (%.1f, %.1f, %.1f) to (%.1f, %.1f, %.1f)\nDist = %.2f\n',mpos1(1),mpos1(2),mpos1(3),mpos_new(2),mpos_new(3),mpos_new(4),dist1);
    fprintf('Changing position 2 from (%.1f, %.1f, %.1f) to (%.1f, %.1f, %.1f)\nDist = %.2f\n',mpos2(1),mpos2(2),mpos2(3),mpos_new(6),mpos_new(7),mpos_new(8),dist2);
end
guidata(handles.figure1,handles);
Goto_Manul_Point_Position(handles);
% UpdateDisplay(handles,[1 3 5]);

% --------------------------------------------------------------------
function Refine_Method_1_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=1;
guidata(handles.figure1,handles);

% --------------------------------------------------------------------
function Refine_Method_2_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=2;
guidata(handles.figure1,handles);

% --------------------------------------------------------------------
function Refine_Method_3_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=3;
guidata(handles.figure1,handles);
guidata(handles.figure1,handles);


% --------------------------------------------------------------------
function Refine_Method_4_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=4;
guidata(handles.figure1,handles);


% --------------------------------------------------------------------
function Refine_Method_5_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=5;
guidata(handles.figure1,handles);


% --------------------------------------------------------------------
function Refine_Bidirection_Menuitem_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Bidirection_Menuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(hObject,'checked') , 'on')==1
    set(hObject,'Checked','off') ;
    handles.PositionRefineBidirectional=0;
else
    set(hObject,'Checked','on') ;
    handles.PositionRefineBidirectional=1;
end
guidata(handles.figure1,handles);


% --------------------------------------------------------------------
function Refine_Method_7_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=7;
guidata(handles.figure1,handles);



% --- Executes on button press in checkbox_hide_all_features.
function checkbox_hide_all_features_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_hide_all_features (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_hide_all_features
handles.hide_all_features = get(hObject,'Value');
guidata(handles.figure1,handles);
UpdateDisplay(handles);



% --------------------------------------------------------------------
function Refine_Method_6_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=6;
guidata(handles.figure1,handles);

% --------------------------------------------------------------------
function Refine_Method_8_Callback(hObject, eventdata, handles)
% hObject    handle to Refine_Method_8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.PositionRefineMenus,'Checked','off') ;
set(hObject,'checked','on') ;
handles.PositionRefineMethod=8;
guidata(handles.figure1,handles);


% --------------------------------------------------------------------
function Subtract_min_value_menu_item_Callback(hObject, eventdata, handles)
% hObject    handle to Subtract_min_value_menu_item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(hObject,'checked') , 'on')==1
    set(hObject,'Checked','off') ;
else
    set(hObject,'Checked','on') ;
end

% --------------------------------------------------------------------
function Normalize_max_value_menu_item_Callback(hObject, eventdata, handles)
% hObject    handle to Normalize_max_value_menu_item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(hObject,'checked') , 'on')==1
    set(hObject,'Checked','off') ;
else
    set(hObject,'Checked','on') ;
end

% --------------------------------------------------------------------
function Apply_Gaussian_Weighting_menu_item_Callback(hObject, eventdata, handles)
% hObject    handle to Apply_Gaussian_Weighting_menu_item (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(hObject,'checked') , 'on')==1
    set(hObject,'Checked','off') ;
else
    set(hObject,'Checked','on') ;
end


% --- Executes on selection change in popupmenu_score.
function popupmenu_score_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_score contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_score

handles.landmark_scores(handles.indices(handles.nlandmark)) = get(handles.popupmenu_score,'value')-1;
guidata(handles.figure1,handles);
UpdateDisplay(handles);


% --- Executes during object creation, after setting all properties.
function popupmenu_score_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu_manual_score.
function popupmenu_manual_score_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_manual_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_manual_score contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_manual_score

% --- Executes during object creation, after setting all properties.
function popupmenu_manual_score_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_manual_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
